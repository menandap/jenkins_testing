Notes 
=========

Notes Onepage Free Comming Soon HTML5 Template .
Download Free Wordpress Version From : http://www.themefisher.com/items/notes-coming-soon-wordpress-theme/ . 